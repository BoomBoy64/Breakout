package Breakout;

import java.util.ArrayList;

public class Cards {
    public static ArrayList<String> cardList = new ArrayList<String>();
    public Cards(){
        cardList.clear();
        cardList.add("Accelerator");
        cardList.add("Jump");
        cardList.add("Ghost Ball");
        cardList.add("Kickup");
        cardList.add("Straight Shooter");
        cardList.add("Stunning Hit");
        cardList.add("SPEED");
    }
    public static ArrayList getCardList(){
        return (cardList);
    }
    public static String[] GenerateCards(ArrayList cards, ArrayList<String> playerCards)
    {
            ArrayList<String> generatableCards = new ArrayList<String>();
            for(int i =0;i< cards.size();i++)
            {
                if(!playerCards.contains(cards.get(i))){
                    generatableCards.add((String) cards.get(i));
                }
            }
            String[] cardChoices = {"", "", ""};
      int cardNumber = (int)(Math.random()*generatableCards.size());
            cardChoices[0] = (String) generatableCards.get(cardNumber);
            generatableCards.remove(cardNumber);
          cardNumber = (int)(Math.random()*generatableCards.size());
            cardChoices[1] = (String)generatableCards.get(cardNumber);
            generatableCards.remove(cardNumber);
          cardNumber = (int)(Math.random()*generatableCards.size());
            cardChoices[2] = (String)generatableCards.get(cardNumber);
            generatableCards.remove(cardNumber);
            return(cardChoices);
    }
}
