package Breakout;

import javax.swing.JFrame; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Graphics extends JFrame
{
	private static final int WIDTH = 2400;
	private static final int HEIGHT = 1200;

	public Graphics()
	{
		super("BreakoutUltimate");

		setSize(WIDTH,HEIGHT);

		getContentPane().add(new Maps((int)(Math.random()*3)+1));

		setVisible(true);

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setResizable(false); 
	}

	public static void main( String args[] )
	{
		Graphics run = new Graphics();
	}
}