package Breakout;


import java.awt.Font;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Canvas;


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.InputEvent;
import java.util.ArrayList;


public class Maps extends JPanel implements Runnable, KeyListener, ActionListener
{
	private Timer timer;
	private int delay = 8;
	public double p1x = 400;
	public double p1y = 1000;
	public double p1vx = 0;
	public double p1vy = 0;
	public int p1ts=0;
	public int p1ss=0;
	public ArrayList<String> p1CardList = new ArrayList<String>();
	public int p1MaxJumps=1;
	public int p1Jumps = 1;

	public int cside = 1;
	public int inching = 1;
	public int cacc = 100;
	public int fin = 0;

	public double p2x = 2000;
	public double p2y = 1000;
	public double p2vx = 4;
	public double p2vy = 4;
	public int p2ts=0;
	public int p2ss=0;
	public int p2MaxJumps=1;
	public int p2Jumps = 1;
	public ArrayList<String> p2CardList = new ArrayList<String>();

	public double bx = 1200;
	public double by = 700;
	public double bxv = -20+(40*Math.random());
	public double byv = 0;
	public double bg = 0.5;
	public double bc = 0.9;

	public int selector = 0;

	private int leftPress = 0;
	private int rightPress = 0;
	private int aPress = 0;
	private int dPress = 0;

	public Color bColor = Color.YELLOW;
	public Color bBackColor = Color.orange;
	ArrayList<Sqrs> sqrList = new ArrayList<Sqrs>();
	//s is solid, p is platform, b is brick, n is none
	public int mapSelect = 0;
	public int menuX = 2;

	public String cardOpt1;
	public String cardOpt2;
	public String cardOpt3;
	ArrayList<String> currentCards = new ArrayList<String>();

	private String winText;
	private Color winColor;
	public int p1stunTimer;
	public int p2stunTimer;

	public Maps(int mapSelect)
	{
		setBackground(Color.WHITE);
		setVisible(true);

		addKeyListener(this);
		setFocusable(true);
		setFocusTraversalKeysEnabled(false);
		timer = new Timer(delay, this);
		timer.start();
		new Thread(this).start();
		new Cards();
	}


	public void bcollide(char collider, String side)
	{
		if(side.equals("top"))
		{
			if(collider == 's'){
				by-=byv;
				byv*=-bc;
			}
		}
		if(side.equals("side"))
		{
			if(collider == 's'){
				bx-=bxv;
				bxv*=-bc;
			}
		}
		if(side.equals("bottom"))
		{
			if(collider == 's'){
				byv*=-bc;
			}
		}
	}
	public void update(Graphics window)
	{
		paint(window);
	}
	public void actionPerformed(ActionEvent e) {
		timer.start();
	}
	public void paint(Graphics window) {

		if(mapSelect<1||mapSelect>3)
		{
			bx=1150;
			by = 700;
			byv = 0;
		}
		if(mapSelect!=0 && p1ts<3 && p2ts<3)
		{
			//Ball Gravity Stuff
			if(bBackColor!=Color.orange)
				if(currentCards.contains("Straight Shooter")) {
					bg = 0;
					bxv/=0.995;
					byv/=0.99;
				}
			else
				bg = 0.5;
			if(currentCards.contains("Accelerator")) {
				bxv *= 1.25;
			}

			byv+=bg;
			by +=byv;
			bx +=bxv;
			bxv*=0.995;
			byv*=0.99;
			if(p1stunTimer>0)
				p1stunTimer--;
			if(p2stunTimer>0)
				p2stunTimer--;
			if(byv>20)
				byv=20;
			if(byv<-20)
				byv=-20;
			if(bxv>25)
				bxv=25;
			if(bxv<-25)
				bxv=-25;

			//Player Movement
			if(p1CardList.contains("SPEED"))
				p1x+=p1vx*5;
			p1x+=p1vx;
			if(p2CardList.contains("SPEED"))
				p2x+=p2vx*5;
			p2x+=p2vx;


			//Figuring out collisions and I realize it's going to act like a square
			//p1 vs ball
			if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p1x, (int)p1y, 100, 150))) {
				if(bBackColor==Color.BLUE && p2CardList.contains("Stunning Hit"))
				{
					p1stunTimer = 60;
				}
				bColor = Color.PINK;
				bBackColor = Color.RED;
				currentCards = p1CardList;
				//top side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p1x, (int)p1y, 100, (int)byv))){
					bcollide('s', "top");
					byv-=15;
					bxv = (bx+25-(p1x+50))/10;
					byv=-Math.abs(byv);
					byv+=p1vy;
				}
				//left side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p1x, (int)p1y, 25, 150))&&((bxv>10&&Math.abs(byv)<3)||bxv>0)){
					bcollide('s', "side");
					byv-=5+((by+50)-p1y)/10;
					bxv-=5;
				}
				//right side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p1x+75, (int)p1y, 25, 150))&&((bxv<10&&Math.abs(byv)<3)||bxv<0)){
					bcollide('s', "side");
					byv-=5+((by+50)-p1y)/10;
					bxv+=5;
				}
				//bottom side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p1x+5, (int)p1y+125, 90, 25))){
					bcollide('s', "bottom");
					byv*=0.25;
					p1y -= p1vy;
					p1vy = 0;
				}
				if(p1CardList.contains("Kickup"))
					byv*=1.25;
				if(p1CardList.contains("Accelerator"))
					bxv*=1.5;
				bxv+=p1vx;
			}
			//p2 vs ball
			if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p2x, (int)p2y, 100, 150))) {
				if(bBackColor==Color.RED && p1CardList.contains("Stunning Hit"))
				{
					p2stunTimer = 60;
				}
				bColor = Color.CYAN;
				bBackColor = Color.BLUE;
				currentCards = p2CardList;
				//top side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p2x, (int)p2y, 100, (int)byv))){
					bcollide('s', "top");
					byv-=15;
					bxv = (bx+25-(p2x+50))/10;
					byv=-Math.abs(byv);
					byv+=p2vy;
				}
				//left side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p2x, (int)p2y, 25, 150))&&((bxv>10&&Math.abs(byv)<3)||bxv>0)){
					bcollide('s', "side");
					byv-=5+((by+50)-p2y)/10;
					bxv-=5;
				}
				//right side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p2x+75, (int)p2y, 25, 150))&&((bxv<10&&Math.abs(byv)<3)||bxv<0)){
					bcollide('s', "side");
					byv-=5+((by+50)-p2y)/10;
					bxv+=5;
				}
				//bottom side
				if(new Rectangle((int)bx, (int)by, 50, 50).intersects(new Rectangle((int)p2x+5, (int)p2y+125, 90, 25))){
					bcollide('s', "bottom");
					byv*=0.25;
					p2y -= p2vy;
					p2vy = 0;
				}
				if(p2CardList.contains("Kickup"))
					byv*=1.25;
				if(p2CardList.contains("Accelerator"))
					bxv*=1.5;
				bxv+=p2vx;
			}
			for (int i=0; i<sqrList.size(); i++) {
				if(sqrList.get(i).col=='s') {
					//P1's solid collision
					if (new Rectangle((int) p1x, (int) p1y, 100, 150).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h))) {
						if (p1y + 150 <= sqrList.get(i).y + p1vy || p1y >= sqrList.get(i).y + sqrList.get(i).h + p1vy) {
							p1y -= p1vy;
							p1vy = 0;
							p1vx*=0.4;
							p1Jumps=p1MaxJumps;
						}
						if (p1x+100 <=sqrList.get(i).x + p1vx) {
							p1x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)-100*Math.signum(p1vx);
							p1vx = 0;
						}
						if (p1x >= sqrList.get(i).x + sqrList.get(i).w + p1vx) {
							p1x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)*Math.signum(p1vx);
							p1vx = 0;
						}
					}
					//P2's solid collision
					if (new Rectangle((int) p2x, (int) p2y, 100, 150).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h))) {
						if (p2y + 150 <= sqrList.get(i).y + p2vy || p2y >= sqrList.get(i).y + sqrList.get(i).h + p2vy) {
							p2y -= p2vy;
							p2vy = 0;
							p2vx*=0.4;
							p2Jumps=p2MaxJumps;
						}
						if (p2x+100 <= sqrList.get(i).x + p2vx) {
							p2x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)-100*Math.signum(p2vx);
							p2vx = 0;
						}
						if (p2x >= sqrList.get(i).x + sqrList.get(i).w + p2vx) {
							p2x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)*Math.signum(p2vx);
							p2vx = 0;
						}
					}
					//Ball's solid collision
					if (new Rectangle((int) bx, (int) by, 50, 50).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h))) {
						if (by + 49 <= sqrList.get(i).y + byv) {
							bcollide('s', "top");
						}
						if (bx + 49 <= sqrList.get(i).x + bxv || bx >= sqrList.get(i).x + sqrList.get(i).w + bxv) {
							bcollide('s', "side");
						}
						if (by >= sqrList.get(i).y + sqrList.get(i).h) {
							bcollide('s', "bottom");
						}
						if (new Rectangle((int) bx+5, (int) by+5, 40, 40).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h-5))){
							byv = (by-sqrList.get(i).y)/5;
						}
					}
				}
				if(sqrList.get(i).col=='b') {
					//P1's brick collision
					if (new Rectangle((int) p1x, (int) p1y, 100, 150).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h))) {
						if (p1y + 150 <= sqrList.get(i).y + p1vy || p1y >= sqrList.get(i).y + sqrList.get(i).h + p1vy) {
							p1y -= p1vy;
							p1vy = 0;
							p1vx*=0.4;
							p1Jumps=p1MaxJumps;
						}
						if (p1x+100 <=sqrList.get(i).x + p1vx) {
							p1x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)-100*Math.signum(p1vx);
							p1vx = 0;
						}
						if (p1x >= sqrList.get(i).x + sqrList.get(i).w + p1vx) {
							p1x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)*Math.signum(p1vx);
							p1vx = 0;
						}
					}
					//P2's brick collision
					if (new Rectangle((int) p2x, (int) p2y, 100, 150).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h))) {
						if (p2y + 150 <= sqrList.get(i).y + p2vy || p2y >= sqrList.get(i).y + sqrList.get(i).h + p2vy) {
							p2y -= p2vy;
							p2vy = 0;
							p2vx*=0.4;
							p2Jumps=p2MaxJumps;
						}
						if (p2x+100 <= sqrList.get(i).x + p2vx) {
							p2x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)-100*Math.signum(p2vx);
							p2vx = 0;
						}
						if (p2x >= sqrList.get(i).x + sqrList.get(i).w + p2vx) {
							p2x = sqrList.get(i).x+(sqrList.get(i).w/2) - (sqrList.get(i).w/2)*Math.signum(p2vx);
							p2vx = 0;
						}
					}
					//Ball's brick collision
					if (new Rectangle((int) bx, (int) by, 50, 50).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h)) && !currentCards.contains("Ghost Ball")) {
						if (by + 49 <= sqrList.get(i).y + byv) {
							bcollide('s', "top");
						}
						if (bx + 49 <= sqrList.get(i).x + bxv || bx >= sqrList.get(i).x + sqrList.get(i).w + bxv) {
							bcollide('s', "side");
						}
						if (by >= sqrList.get(i).y + sqrList.get(i).h) {
							bcollide('s', "bottom");
						}
						if (new Rectangle((int) bx+5, (int) by+5, 40, 40).intersects(new Rectangle((int) sqrList.get(i).x, (int) sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h-5))){
							byv = (by-sqrList.get(i).y)/5;
						}
						bxv*=1/bc;
						sqrList.remove(i);
					}
				}
			}
		}

		//Scoring code
		if (bx>2400)
		{
			p1x=400;
			p2x=2000;
			p1y=1000;
			p2y=1000;
			bx = 1200;
			by = 700;
			byv = 0;
			bxv = 0;
			p1ss++;
			if(bBackColor==Color.red)
				p1CardList = currentCards;
			if(bBackColor==Color.blue)
				p2CardList = currentCards;
			bColor = Color.CYAN;
			bBackColor = Color.BLUE;
			if(p1ss==2) {
				p1ss = 0;
				p1ts++;
				p2ss = 0;
				if(p1ts<3) {
					mapSelect=4;
					selector = 2;
					String[] cardsGenerated = Cards.GenerateCards(Cards.getCardList(), p2CardList);
					cardOpt1 = cardsGenerated[0];
					cardOpt2 = cardsGenerated[1];
					cardOpt3 = cardsGenerated[2];
					bx = 1200;
					by = 700;
					bxv = -20+(40*Math.random());
					byv = 0;
				}else{
					mapSelect=5;
					winColor = Color.RED;
					winText = "RED WINS";
				}
			}
		}
		if (bx<0)
		{
			p1x=400;
			p2x=2000;
			p1y=1000;
			p2y=1000;
			p2ss++;
			bx = 1200;
			by = 700;
			byv = 0;
			bxv = 0;
			if(bBackColor==Color.red)
				p1CardList = currentCards;
			if(bBackColor==Color.blue)
				p2CardList = currentCards;
			bColor = Color.PINK;
			bBackColor = Color.RED;
			if(p2ss==2) {
				p2ss = 0;
				p2ts+=1;
				p1ss = 0;
				if(p2ts<3) {
					mapSelect=4;
					selector = 1;
					String[] cardsGenerated = Cards.GenerateCards(Cards.getCardList(), p1CardList);
					cardOpt1 = cardsGenerated[0];
					cardOpt2 = cardsGenerated[1];
					cardOpt3 = cardsGenerated[2];
					bx = 1200;
					by = 700;
					bxv = -20+(40*Math.random());
					byv = 0;
				}else{
					mapSelect=5;
					winColor = Color.BLUE;
					winText = "BLUE WINS";
				}
			}
		}

		//Background
		window.setColor(Color.BLACK);
		if(sqrList.size()==0)
		{
			//Beginning Sqrs
			//Black Sqrs (6 for bg)
			sqrList.add(new Sqrs(0, 0, 2400, 40,'s'));
			sqrList.add(new Sqrs(0, 0, 100, 400,'s'));
			sqrList.add(new Sqrs(0, 800, 100, 400,'s'));
			sqrList.add(new Sqrs(0,1120,2400,80,'s'));
			sqrList.add(new Sqrs(2300,800,100,400,'s'));
			sqrList.add(new Sqrs(2300,0,100,400,'s'));
			//Gray Sqrs (2 for bg)
			sqrList.add(new Sqrs(100, 40, 2200, 1080,'n'));
			sqrList.add(new Sqrs(0,400,2400,400,'n'));
		}
		for (int i=0; i<6; i++)
		{
			window.fillRect(sqrList.get(i).x, sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h);
		}
		window.setColor(Color.GRAY);
		for (int i=6; i<8; i++)
		{
			window.fillRect(sqrList.get(i).x, sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h);
		}
		//Foreground
		window.setColor(Color.green);
		if(mapSelect==0)
		{
			bColor = Color.YELLOW;
			bBackColor = Color.orange;
			window.setColor(Color.DARK_GRAY);
			if(menuX!=1)
			window.fillRect(400,450, 400, 300);
			else
				window.fillRect(350,400, 500, 400);
			if(menuX!=2)
			window.fillRect(1000,450, 400, 300);
			else
				window.fillRect(950, 400, 500, 400);
			if(menuX!=3)
			window.fillRect(1600,450, 400, 300);
			else
				window.fillRect(1550, 400, 500, 400);

			window.setColor(Color.white);
			window.setFont(new Font("TAHOMA",Font.BOLD,40));
			window.drawString("1",600,600);
			window.drawString("2",1200,600);
			window.drawString("3",1800,600);

		} else if (mapSelect==4)
		{
			window.setColor(Color.DARK_GRAY);
			if(menuX!=1)
				window.fillRect(400,450, 400, 300);
			else
				window.fillRect(350,400, 500, 400);
			if(menuX!=2)
				window.fillRect(1000,450, 400, 300);
			else
				window.fillRect(950, 400, 500, 400);
			if(menuX!=3)
				window.fillRect(1600,450, 400, 300);
			else
				window.fillRect(1550, 400, 500, 400);

			window.setColor(Color.white);
			window.setFont(new Font("TAHOMA",Font.BOLD,40));
			window.drawString(cardOpt1,550-cardOpt1.length()*7,600);
			window.drawString(cardOpt2,1150-cardOpt2.length()*7,600);
			window.drawString(cardOpt3,1750-cardOpt3.length()*7,600);
		} else if(mapSelect==5) {
			window.setColor(Color.WHITE);
			window.setFont(new Font("TAHOMA",Font.BOLD,100));
			window.drawString(winText, 950, 600);
			window.setColor(winColor);
			window.setFont(new Font("TAHOMA",Font.BOLD,15));
			window.drawString("Yippee!!", 1200, 700);
		}


		if((mapSelect!=0 && mapSelect!=4 && mapSelect!=5) && (p1ts<3 && p2ts<3))
		{
			//Map Printer (Everything after the base layout printer)
			for (int i=8; i<sqrList.size(); i++)
			{
				if(sqrList.get(i).col=='s')
					window.setColor(Color.black);
				if(sqrList.get(i).col=='p')
					window.setColor(Color.black);
				if(sqrList.get(i).col=='b')
					window.setColor(Color.white);
				window.fillRect(sqrList.get(i).x, sqrList.get(i).y, sqrList.get(i).w, sqrList.get(i).h);
			}
			//Players painter
			window.setColor(Color.black);
			window.fillRect((int)p1x, (int)p1y, 100, 150);
			window.fillRect((int)p2x, (int)p2y, 100, 150);
			window.setColor(Color.RED);
			window.fillRect((int)p1x+5, (int)p1y+5, 90, 140);
			window.setColor(Color.CYAN);
			window.fillRect((int)p2x+5, (int)p2y+5, 90, 140);

			//Ball painter
			window.setColor(bBackColor);
			window.fillOval((int)bx, (int)by, 50, 50);
			window.setColor(bColor);
			window.fillOval((int)bx, (int)by, 45, 45);


			//text (top left)
			window.setColor(Color.WHITE);
			window.setFont(new Font("TAHOMA",Font.BOLD,18));
			window.drawString("Breakout VS",40,40);
			window.drawString(""+mapSelect,40,80);

			//score screen
			window.setColor(Color.BLACK);
			window.fillRect(940, 40, 520, 60);
			window.fillRect(1000, 40, 400, 75);
			window.fillRect(1075, 40, 250, 120);

			window.setColor(Color.darkGray);
			window.fillRect(950, 40, 50, 50);
			window.fillRect(1010, 40, 65, 65);
			window.fillRect(1085, 40, 110, 110);
			window.fillRect(1085, 40, 55, 110);
			window.fillRect(1400, 40, 50, 50);
			window.fillRect(1325, 40, 65, 65);
			window.fillRect(1205, 40, 110, 110);
			window.fillRect(1260, 40, 55, 110);

			window.setColor(Color.RED);
			if(p1ts>=1) window.fillRect(950, 40, 50, 50);
			if(p1ts>=2) window.fillRect(1010, 40, 65, 65);
			if(p1ts>=3) window.fillRect(1085, 40, 110, 110);
			if(p1ss>=1) window.fillRect(1085, 40, 55, 110);

			window.setColor(Color.CYAN);
			if(p2ts>=1) window.fillRect(1400, 40, 50, 50);
			if(p2ts>=2) window.fillRect(1325, 40, 65, 65);
			if(p2ts>=3) window.fillRect(1205, 40, 110, 110);
			if(p2ss>=1) window.fillRect(1260, 40, 55, 110);

			window.setColor(Color.WHITE);
			window.setFont(new Font("TAHOMA",Font.BOLD,18));
			window.drawString(p1CardList.toString(),130,80);
			window.drawString(p2CardList.toString(),2100-10*p2CardList.size(),80);

			//Left & Right Player Movement
			if (p1x<=2290){
				if(dPress==1)
					p1vx=10;}
			else{
				p1vx=0;
				p1x=2290;
			}

				if (p1x>=10){
					if(aPress==1)
					p1vx=-10;}
				else{
				p1vx=0;
					p1x=10;
				}


				if (p2x<=2290){
					if(rightPress==1)
						p2vx=10;}
				else{
					p2vx=0;
					p2x=2290;
				}

				if (p2x>=10){
					if(leftPress==1)
						p2vx=-10;}
				else{
					p2vx=0;
					p2x=10;
				}

			//Base Gravity, only applies if within y bounds
			p1y+=p1vy;
			p2y+=p2vy;
			if(p1y<970)
			{
				p1vy+=0.5;
			}else {
				p1y = 970;
				p1Jumps = p1MaxJumps;
				p1vx *= 0.95;
			}

			if(p2y<970)
			{
				p2vy+=0.5;
			}else {
				p2y = 970;
				p2Jumps = p2MaxJumps;
				p2vx *= 0.95;
			}
		}
	}


	public void run() {
		try
		{
			while(true)
			{

				Thread.currentThread().sleep(10);
				repaint();
			}
		}catch(Exception e)
		{
		}
	}
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_D&&p1stunTimer<=0) {
			dPress=1;
		}
		if(e.getKeyCode() == KeyEvent.VK_A&&p1stunTimer<=0) {
			aPress=1;
		}
		if(e.getKeyCode() == KeyEvent.VK_RIGHT&&p2stunTimer<=0) {
			rightPress=1;
		}
		if(((e.getKeyCode() == KeyEvent.VK_RIGHT  && selector!=1) || (e.getKeyCode() == KeyEvent.VK_D && selector!=2)) && (mapSelect==0||mapSelect==4) && menuX<3) {
			menuX++;
		}
		if(((e.getKeyCode() == KeyEvent.VK_LEFT && selector!=1) || (e.getKeyCode() == KeyEvent.VK_A && selector!=2)) && (mapSelect==0||mapSelect==4) && menuX>1) {
			menuX--;
		}
		if(e.getKeyCode() == KeyEvent.VK_SPACE && mapSelect==0 ) {
			mapSelect = menuX;
			sqrList.clear();
			//Black Sqrs (6 for bg)
			sqrList.add(new Sqrs(0, 0, 2400, 40,'s'));
			sqrList.add(new Sqrs(0, 0, 100, 400,'s'));
			sqrList.add(new Sqrs(0, 800, 100, 400,'s'));
			sqrList.add(new Sqrs(0,1120,2400,80,'s'));
			sqrList.add(new Sqrs(2300,800,100,400,'s'));
			sqrList.add(new Sqrs(2300,0,100,400,'s'));
			//Gray Sqrs (2 for bg)
			sqrList.add(new Sqrs(100, 40, 2200, 1080,'n'));
			sqrList.add(new Sqrs(0,400,2400,400,'n'));
			bColor = Color.YELLOW;
			bBackColor = Color.orange;
			if(mapSelect==1)
			{
				for (int i = 100; i < 1100; i += 150) {
					sqrList.add(new Sqrs(2*i, i, 200, 100, 's'));
					sqrList.add(new Sqrs(2*i, 1100-i, 200, 100, 's'));
					sqrList.add(new Sqrs(2*i, 550, 200, 100, 's'));
				}
			} else if(mapSelect==2)
			{
				sqrList.add(new Sqrs(1000, 820, 400, 300,'s'));
				for (int i = 300; i < 600; i += 75) {
					sqrList.add(new Sqrs(2200, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(2150, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(2100, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(2050, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(2000, i, 45, 70, 'b'));
				}
				for (int i = 300; i < 600; i += 75) {
					sqrList.add(new Sqrs(1075, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1125, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1175, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1225, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1275, i, 45, 70, 'b'));
				}
				for (int i = 300; i < 600; i += 75) {
					sqrList.add(new Sqrs(200, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(250, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(300, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(350, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(400, i, 45, 70, 'b'));
				}

			} else if(mapSelect==3) {
				for (int i = 75; i < 1100; i += 75) {
					sqrList.add(new Sqrs(952, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1002, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1052, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1102, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1152, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1202, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1252, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1302, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1352, i, 45, 70, 'b'));
					sqrList.add(new Sqrs(1402, i, 45, 70, 'b'));
				}
			} else{
				bxv=0;
				byv=0;
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_SPACE && mapSelect==4 ) {
			if(menuX==1){
				if(selector==1)
					p1CardList.add(cardOpt1);
				else if (selector==2) {
					p2CardList.add(cardOpt1);
				}
			} else if(menuX==2){
				if(selector==1)
					p1CardList.add(cardOpt2);
				else if (selector==2) {
					p2CardList.add(cardOpt2);
				}
			} else if(menuX==3){
				if(selector==1)
					p1CardList.add(cardOpt3);
				else if (selector==2) {
					p2CardList.add(cardOpt3);
				}
			}
			if(selector==1) {
				if (p1CardList.contains("Jump"))
					p1MaxJumps = 2;
			}
			else{
				if (p2CardList.contains("Jump"))
					p2MaxJumps = 2;
			}

			selector = 0;
			menuX=2;
			mapSelect=0;
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT&&p2stunTimer<=0) {
			leftPress=1;
		}
		if(e.getKeyCode() == KeyEvent.VK_UP&&p2stunTimer<=0)
		{
			if(p2Jumps>0) {
				p2vy = -20;
				p2Jumps--;
			}
		}
		if(e.getKeyCode() == KeyEvent.VK_W)
		{
			if(p1Jumps>0) {
				p1vy = -20;
				p1Jumps--;
			}
		}
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode() == KeyEvent.VK_D) {
			dPress=0;
		}
		if(e.getKeyCode() == KeyEvent.VK_A) {
			aPress=0;
		}
		if(e.getKeyCode() == KeyEvent.VK_RIGHT) {
			rightPress=0;
		}
		if(e.getKeyCode() == KeyEvent.VK_LEFT) {
			leftPress=0;
		}

	}
}


