package Breakout;

import java.awt.Color; 
import java.awt.Graphics;

public class Sqrs
{
   public int x;
   public int y;
   public int w;
   public int h;
   public char col;
   public Sqrs(int xPos, int yPos, int width, int height, char collider)
   {
		x = xPos;
		y=yPos;
		w=width;
		h=height;
		//Solid = s, Platform = p, None = n, Brick = b...
		col = collider;
   }
}